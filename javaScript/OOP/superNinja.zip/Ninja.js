class Ninja{
     constructor(name,health,speed = 3,strength = 3){
         this.name = name;
         this.health = health;
         this.speed = speed;
         this.strength = strength;
     }

     sayName(){
        console.log(this.name);
     }

     showStats(){
         console.log(
            "Name: "+this.name
            +" Strength: "+this.strength
            +" Speed: "+this.speed
            +" Health: "+this.health);
    }

    drinkSake(x = 10){
        this.health += x;
    }
}


class Sensei extends Ninja{
    constructor(name){
        super(name);
        this.health = 200;
        this.speed = 10;
        this.strength = 10;
        this.wisdom = 10;
    }
    speakWisdom(){
        super.drinkSake();
    }

}

const ninja = new Ninja("Osaid",100);
ninja.sayName();

const sensei = new Sensei("newOsaid");
sensei.sayName();
sensei.drinkSake();
sensei.showStats();