import React, { useState } from 'react';
import './App.css';
import Tabs from './components/Tabs';
function App() {
  const tabContents = [
    ['Tab 1', 'Content for tab 1'],
    ['Tab 2', 'Content for tab 2'],
    ['Tab 3', 'Content for tab 3'],
  ]
  return (
      <header className="App">
        <Tabs tabs={tabContents} />
      </header>
    
  );
}

export default App;
