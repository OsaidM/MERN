import React, { useState } from 'react';


const Tabs = ({ tabs }) => {
    const [tabState, setTabState] = useState({
        index: 99,
        content: []
    })

    const onClickHandler = e => {
        const [, ...contentList] = tabs[e.target.value];
        setTabState({
            index: e.target.value,
            content: contentList
        })
    }

    const resetButton = e => {
        setTabState({
            index: 99,
            content: []
        })
    }

    return (
        <div>
            <h1>Tabs Assignment</h1>
            {tabs.map((tab, index) => {
                return (
                    <button key={index} value={index} onClick={onClickHandler}>{tab[0]}</button>
                )
            })}
            <div>
                {tabState.content.map((c, index) => {
                    return <p key={index}>{c}</p>
                })}
            </div>
            <button onClick={resetButton}>Reset</button>
        </div>
    )
}

export default Tabs;