import React,{useState} from "react";

const PersonCard = (props) =>{
    const [firstName, setFirstName] = useState("");
    const [firstNameError, setFirstNameError] = useState("");
    const [lastName, setLastName] = useState("");
    const [lastNameError, setLastNameError] = useState("");
    const [email, setEmail] = useState("");
    const [emailError, setEmailError] = useState("");
    const [password, setPassword] = useState("");
    const [passwordError, setPasswordError] = useState("");
    const [cPassword, setCPassword] = useState("");
    const [cPasswordError, setCPasswordError] = useState("");
    const [hasBeenSubmitted, setHasBeenSubmitted] = useState(false);
    const createUser = (e) => {
        e.preventDefault();
        const newUser = { firstName,lastName, email, password };
        setHasBeenSubmitted( true );
        console.log("Welcome", newUser);
    }; 
    const formMessage = () => {
        if( hasBeenSubmitted ) {
	    return "Thank you for submitting the form!";
	} else {
	    return "Welcome, please submit the form";
	}
    };

    const handleFirstName = (e) => {
        setFirstName(e.target.value);
        if(e.target.value.length < 1) {
            setFirstNameError("First Name is required!");
        } else if(e.target.value.length < 2) {
            setFirstNameError("field must be at least 2 characters!");
        }else{
            setFirstNameError("");
        }
    }
    const handleLastName = (e) => {
        setLastName(e.target.value);
        if(e.target.value.length < 1) {
            setLastNameError("Last Name is required!");
        } else if(e.target.value.length < 2) {
            setLastNameError("field must be at least 2 characters!");
        }else{
            setLastNameError("");
        }
    }

    const handleEmail = (e) => {
        setEmail(e.target.value);
        if(e.target.value.length < 1) {
            setEmailError("Email is required!");
        } else if(e.target.value.length < 5) {
            setEmailError("field must be at least 5 characters!");
        }else{
            setEmailError("");
        }
    }

    const handlePassword = (e) => {
        setPassword(e.target.value);
        if(e.target.value.length < 1) {
            setPasswordError("Password is required!");
        } else if(e.target.value.length < 8) {
            setPasswordError("field must be at least 8 characters!");
        }else{
            setPasswordError("");
        }
    }

    const handleCPassword = (e) => {
        setCPassword(e.target.value);
        if(e.target.value === password) {
            setCPasswordError("");
        }else{
            setCPasswordError("Password must match");
        }
    }

    return(
        <div>
            <form onSubmit={ (e) => e.preventDefault()}>
                {
                    hasBeenSubmitted ? 
                    <h3>Thank you for submitting the form!</h3> :
                    <h3>Welcome, please submit the form.</h3> 
                }
                <div>
                    <label>First Name: </label> 
                    <input type="text" onChange={ (e) => setFirstName(e.target.value),handleFirstName } value={ firstName } />
                    {
                    firstNameError ?
                    <p style={{color:'red'}}>{ firstNameError }</p> :
                    ''
                    }
                </div>
                <div>
                    <label>Last Name: </label> 
                    <input type="text" onChange={ (e) => setLastName(e.target.value),handleLastName } value={ lastName } />
                    {
                    lastNameError ?
                    <p style={{color:'red'}}>{ lastNameError }</p> :
                    ''
                    }
                </div>
                <div>
                    <label>Email Address: </label> 
                    <input type="text" onChange={ (e) => setEmail(e.target.value), handleEmail } value={ email }  />
                    {
                    emailError ?
                    <p style={{color:'red'}}>{ emailError }</p> :
                    ''
                    }
                </div>
                <div>
                    <label>Password: </label>
                    <input type="text" onChange={ (e) => setPassword(e.target.value), handlePassword } value={ password } />
                    {
                    passwordError ?
                    <p style={{color:'red'}}>{ passwordError }</p> :
                    ''
                    }
                </div>
                <div>
                    <label>Confirm Password: </label>
                    <input type="text" onChange={ (e) => setCPassword(e.target.value), handleCPassword } value={ cPassword } />
                    {
                    cPasswordError ?
                    <p style={{color:'red'}}>{ cPasswordError }</p> :
                    ''
                    }
                </div>
                <input type="submit"/>
            </form>
            <hr/>
            <h5>Form Data</h5>
            <ul>
                <li>first Name: {firstName}</li>
                <li>Last Name: {lastName}</li>
                <li>Email: {email}</li>
                <li>Password: {password}</li>
                <li>Confirm Password: {password}</li>
            </ul>
        </div>
        );
}

export default PersonCard;