import './App.css';
import PersonCard from './components/PersonCard';
function App() {
  return (
      <header className="App">
        <PersonCard/>
      </header>
    
  );
}

export default App;
