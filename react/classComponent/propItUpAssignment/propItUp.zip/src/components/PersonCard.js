import React, { Component } from "react";

class PersonCard extends Component{
    constructor(props) {
        super(props);
        this.state = {
            counter:0
        };
    }

    incAge(){
        const count= this.state.counter+1;
        this.setState({counter: count});
        return count;
    }
    render(){
        const { firstName, lastName } = this.props;
        return (<div><h1>{ this.props.firstName }, { this.props.lastName }</h1>
        <p>Age: {this.props.age+this.state.counter}</p>
        <p>Hair Color: {this.props.hairColor}</p>
        { this.props.children }
            <button onClick={ () => this.incAge() }>Birthday button for { this.props.firstName } { this.props.lastName }</button>

        </div>);
    }
}

export default PersonCard;