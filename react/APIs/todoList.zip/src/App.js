import React from 'react';
import Input from './components/Task';
import './App.css';
function App() {
  return (
    <div className="App">
    <Input/>
    </div>
    
  );
}

export default App;
