import React from 'react';
import Input from './components/Input';
//import './App.css';
import './Try.css';
function App() {
  return (
    <div className="App">
    <Input/>
    </div>
    
  );
}

export default App;
