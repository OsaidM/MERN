import React from 'react';
import Input from './components/Input';
import './App.css';
function App() {
  return (
    <div className="App container">
    <Input/>
    </div>
    
  );
}

export default App;
